#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main(int argc, char* argv[]) {
	int size = atoi(argv[1]);
	char buf[size];
	
	cin.read(buf,size);
	while(!cin.eof()){
		cout.write(buf,size);
		cin.read(buf,size);
	}
	
	return 0;
}
