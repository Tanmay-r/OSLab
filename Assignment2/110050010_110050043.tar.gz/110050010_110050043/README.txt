Assignment 2

110050010 - Tanmay Randhavane
110050043 - Alok Yadav

Command = 
1) g++ main.cpp
2) ./a.out