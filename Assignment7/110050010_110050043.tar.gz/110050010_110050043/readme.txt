110050010	Tanmay Randhavane
110050043	Alok Yadav

Assignment 7

Command to run = g++ -pthread ipc.cpp -o ipc


